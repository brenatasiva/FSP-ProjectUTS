<?php 
session_start();
if(!isset($_SESSION['username'])){
	header("location: login.php");
}
include "db.php";
require_once("class/movie.php");
require_once("class/genre.php");
require_once("class/poster.php");
require_once("class/pemain.php");
$mysqli = new mysqli("localhost","root","","fullstack");
if($mysqli->connect_errno){
	echo "Failed to connect to MySQL: ".$mysqli->connect_error;
}
$data_per_page = 2;
$halaman_ke = (isset($_GET['page'])) ? $_GET['page'] : 1;
if(!is_numeric($halaman_ke)) $halaman_ke=1;
$offset = $data_per_page * ($halaman_ke - 1);
?>

<!DOCTYPE html>
<html>
<head>
	<title>My Movie</title>
	<script type="text/javascript" src="jquery.js"></script>
</head>
<style type="text/css">
	table,th,td,tr {border-style: solid;}
	table {border-collapse: collapse; width: 90%; text-align: center;}
	#header {height: 75px; padding: 10px;}
	#nav {height: 300px; width: 11%; padding-top: 10px; text-align: center; float: left;}
	#content {padding-left: 210px; min-height: 250px;}
	#buttontambah {border-radius: 20px; margin-left: 75%; padding: 10px 25px}
	#div-button {padding: 10px 0px; }
	#txt {margin-right: 10px; border-width: 3px; border-radius: 4px; margin-left: 25px;}
	#btn {border-radius: 20px; width:6em; height: 2em;}
	img	{height: 200px; width: 150px;}

	#div-list-movie {display: flex; flex-direction: column;}
	#div-movie {display: flex; margin-bottom: 20px; border:1px solid black; padding: 5px;}
	#div-deskripsi {padding-left: 25px}
	a {text-decoration: none; color: black;}
	a:visited{color: black;}
	#a_movie:hover {color:red;}
</style>
<script type="text/javascript" src="jquery.js"></script>
<body>
	<div id=container>
		<div id=header>
			<h1>
				<?php 
					echo "Halo, ".$_SESSION['nama'];
				?>
			<form method="post" action="logout.php">
				<button type="submit" name="logout">LOGOUT</button>
			</form>
			</h1>
		</div>
		<div id=nav>
			<?php  
				$sql = "SELECT m.link, m.nama from menu m inner join menu_profile mp on m.idmenu = mp.idmenu where mp.idprofile = ".$_SESSION['profile'];
				$result = $mysqli->query($sql);

				while($row = $result->fetch_assoc()){
					echo "<a href='".$row['link']."'>".$row['nama']."</a><br>";
				}
			?>

		</div>
		<div id=content>
			<div id="div-cari">
				<label style="font-size: 20px;">Daftar Movie</label><br>
				<form method="get" action="">
					<label>Masukan Judul</label><input type="text" name="txtcari" id=txt><input type="submit" name="btncari" value="search" id=btn>
				</form>
			</div>
			<div id="div-button">
				<a href="insertmovie.php"><button type="button" id="buttontambah" >Tambah Movie Baru</button></a>
				
			</div>
			<div id="div-list-movie">
				<?php 
					$arr_genre=array();
					$arr_gambar=array();
					$arr_pemain=array();

					$objGenre = new genre($SERVER, $USERID, $PWD, $DB);
					$res_genre = $objGenre->getGenreMovie();

					while($row=$res_genre->fetch_assoc()){
						$arr_genre[$row['idmovie']][]=$row['nama'];
					}

					$objPoster = new poster($SERVER, $USERID, $PWD, $DB);
					$res_gambar = $objPoster->getPoster();

					while($row_gambar=$res_gambar->fetch_assoc()){
						$arr_gambar[$row_gambar['idmovie']][]=$row_gambar['idgambar'].".".$row_gambar['extention'];
					}

					$objPemain = new pemain($SERVER, $USERID, $PWD, $DB);
					$res_pemain = $objPemain->getPemain();

					while ($row_pemain=$res_pemain->fetch_assoc()) {
						$arr_pemain[$row_pemain['idmovie']][]=$row_pemain['nama'];
					}

						$cari=(isset($_GET['btncari'])) ? $_GET['txtcari'] : "";
						$keyword="%".$cari."%";
						$objMovie = new movie($SERVER, $USERID, $PWD, $DB);
						$res = $objMovie->getMovie($keyword);

						$total_data=$res->num_rows;
						$res = $objMovie->getMovie($keyword, $offset, $data_per_page, null);
					
						
					while($row=$res->fetch_assoc()){
						echo "<a href='halaman_detil.php?id=".$row['idmovie']."' id='a_movie'><div id='div-movie'>";
						echo 	"<div id='div-gambar'>";
							if(isset($arr_gambar[$row['idmovie']])){
								$arr_kumpulan_gambar=$arr_gambar[$row['idmovie']];
								echo "<img src='img/".$arr_kumpulan_gambar[0]."'>";
							}
							echo "</div>";
							echo "<div id='div-deskripsi'>";
							echo 	"<h1 id='judul'>".$row['judul']."</h1>";
							echo 	"<p id='tgl-rilis'>Tanggal Rilis: ".date("d M Y",strtotime($row['rilis']))."</p>";
							echo 	"<p id='sinopsis'>Sinopsis: ".$row['sinopsis']."</p>";
							echo "</div>";
						echo "</div></a>";
					}
					
				?>
			</div>
				<p>
					<?php  
						include "helper/pagenumber.php";
						generate_page_number($data_per_page, $total_data, $cari, $halaman_ke);
					?>
				</p>
			
			
		</div>
	</div>

</body>
</html>
<?php  
$mysqli->close();
?>